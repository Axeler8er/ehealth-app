package com.example.ehealthapp.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Repository for storing and retrieving medication reminders. The reminders
 * are serialised as pipe separated strings and persisted in a string set
 * preference. When retrieved they are parsed back into [MedicationReminder]
 * objects and sorted by their scheduled time (hour * 60 + minute).
 */
class ReminderRepository(private val context: Context) {
    private val Context.dataStore by preferencesDataStore(name = "reminder_prefs")
    private val REMINDERS = stringSetPreferencesKey("med_reminders")

    /** Flow emitting the list of reminders sorted by time of day. */
    val reminders: Flow<List<MedicationReminder>> = context.dataStore.data.map { prefs ->
        prefs[REMINDERS]?.mapNotNull { parseReminder(it) }
            ?.sortedBy { it.hour * 60 + it.minute } ?: emptyList()
    }

    /** Add a new reminder to DataStore. */
    suspend fun addReminder(reminder: MedicationReminder) {
        context.dataStore.edit { prefs ->
            val current = prefs[REMINDERS]?.toMutableSet() ?: mutableSetOf()
            current.add(formatReminder(reminder))
            prefs[REMINDERS] = current
        }
    }

    private fun formatReminder(reminder: MedicationReminder): String =
        "${reminder.id}|${reminder.name}|${reminder.hour}|${reminder.minute}"

    private fun parseReminder(str: String): MedicationReminder? {
        val parts = str.split("|")
        return if (parts.size == 4) {
            try {
                val id = parts[0].toLong()
                val name = parts[1]
                val hour = parts[2].toInt()
                val minute = parts[3].toInt()
                MedicationReminder(id, name, hour, minute)
            } catch (e: Exception) {
                null
            }
        } else null
    }
}