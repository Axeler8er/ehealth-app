package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * CBT practices screen listing a handful of cognitive behavioural
 * techniques that the user can explore. Each item is presented in a
 * card with a title and a short description to inspire learning and
 * reflection.
 */
@Composable
fun CBTPracticesScreen() {
    val practices = listOf(
        "Выявление автоматических мыслей" to "Замечайте автоматические негативные мысли и оспаривайте их.",
        "Когнитивная реструктуризация" to "Переформулируйте негативные убеждения на более реалистичные.",
        "Поведенческий эксперимент" to "Проверяйте свои убеждения на практике.",
        "Планирование удовольствий" to "Включайте в расписание приятные и полезные занятия."
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CBT Практики", style = MaterialTheme.typography.titleLarge)
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 12.dp)
        ) {
            items(practices) { (title, desc) ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        Text(desc, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}