package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.ehealthapp.R

/**
 * Screen showing information about the mobile harm reduction service
 * sometimes called the "Blue Bus". Because this prototype is offline
 * the schedule is static and serves as an example. The mascot holding
 * a bus sign reinforces the concept.
 */
@Composable
fun BusLocationScreen() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Синий автобус", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(id = R.drawable.bus_mascot),
            contentDescription = null,
            modifier = Modifier.height(150.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "График работы:\nПн: 10:00–14:00 на площади X\nСр: 12:00–16:00 у станции метро Y\nПт: 14:00–18:00 в районе Z\n\nЗдесь вы можете получить стерильные шприцы и Налоксон.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}