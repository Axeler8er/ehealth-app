package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * A very simple ELIZA‑like chatbot. The bot reflects user inputs back
 * with basic pronoun substitution. Messages are displayed in order and
 * the conversation persists during the screen session. This does not
 * provide any therapeutic advice but offers a space to vent.
 */
@Composable
fun ElizaScreen() {
    val conversation = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    fun elizaResponse(message: String): String {
        // naive pronoun substitution for demonstration
        var response = message
            .replace("я", "вы", ignoreCase = true)
            .replace("меня", "вас", ignoreCase = true)
            .replace("мне", "вам", ignoreCase = true)
        return "Почему вы думаете, что $response?"
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Чат с Элизой", style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(conversation) { (user, bot) ->
                Text("Вы: $user", style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
                Text("Элиза: $bot", style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
            }
        }
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Ваше сообщение") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Button(onClick = {
            if (input.isNotBlank()) {
                val userMsg = input.trim()
                val botMsg = elizaResponse(userMsg)
                conversation.add(userMsg to botMsg)
                input = ""
            }
        }, modifier = Modifier.align(Alignment.End)) {
            Text("Отправить")
        }
    }
}