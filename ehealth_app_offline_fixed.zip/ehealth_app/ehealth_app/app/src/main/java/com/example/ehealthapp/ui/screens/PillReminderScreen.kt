package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ehealthapp.data.MedicationReminder
import com.example.ehealthapp.viewmodel.ReminderViewModel

/**
 * Screen allowing the user to view existing medication reminders and
 * schedule new ones. Each reminder includes a medication name and a
 * time of day expressed as hour and minute. Input validation is kept
 * minimal for demo purposes.
 */
@Composable
fun PillReminderScreen(viewModel: ReminderViewModel = viewModel()) {
    val reminders by viewModel.reminders.collectAsState()
    var name by remember { mutableStateOf("") }
    var hour by remember { mutableStateOf("") }
    var minute by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Напоминания о приёме", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(reminders) { reminder ->
                Text(
                    text = "${reminder.name}: %02d:%02d".format(reminder.hour, reminder.minute),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        // Input form
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Название препарата") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = hour,
                onValueChange = { hour = it.filter { ch -> ch.isDigit() } },
                label = { Text("Часы") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = minute,
                onValueChange = { minute = it.filter { ch -> ch.isDigit() } },
                label = { Text("Минуты") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val h = hour.toIntOrNull()
                val m = minute.toIntOrNull()
                if (!name.isBlank() && h != null && m != null && h in 0..23 && m in 0..59) {
                    viewModel.addReminder(MedicationReminder(name = name.trim(), hour = h, minute = m))
                    name = ""
                    hour = ""
                    minute = ""
                }
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Добавить")
        }
    }
}