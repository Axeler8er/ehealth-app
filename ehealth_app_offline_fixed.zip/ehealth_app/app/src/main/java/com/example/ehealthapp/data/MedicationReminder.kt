package com.example.ehealthapp.data

/**
 * Represents a single medication reminder. Each reminder stores an
 * identifier so that it can be distinguished within a list, the
 * medication name and a time of day (hour/minute) when the user
 * should take the medication. All fields are immutable to ensure
 * thread safety when sharing between coroutines.
 */
data class MedicationReminder(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val hour: Int,
    val minute: Int
)