package com.example.ehealthapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ehealthapp.data.MedicationReminder
import com.example.ehealthapp.data.ReminderRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel for medication reminders. Provides a state flow of all
 * scheduled reminders and a method to insert new ones. All data is
 * persisted locally via [ReminderRepository].
 */
class ReminderViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ReminderRepository(application)

    val reminders: StateFlow<List<MedicationReminder>> = repository.reminders.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    fun addReminder(reminder: MedicationReminder) {
        viewModelScope.launch {
            repository.addReminder(reminder)
        }
    }
}