package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.Add
import androidx.compose.material3.icons.filled.Remove
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ehealthapp.viewmodel.InventoryViewModel

/**
 * Inventory screen for tracking remaining pill counts of various
 * medications. Users can increment or decrement counts and add new
 * medications by specifying a name and initial quantity.
 */
@Composable
fun PillInventoryScreen(viewModel: InventoryViewModel = viewModel()) {
    val inventory by viewModel.inventory.collectAsState()
    var newName by remember { mutableStateOf("") }
    var newCount by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Запасы таблеток", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(inventory.toList()) { (name, count) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    IconButton(onClick = {
                        if (count > 0) viewModel.setCount(name, count - 1)
                    }) {
                        Icon(Icons.Default.Remove, contentDescription = "Уменьшить")
                    }
                    Text(count.toString(), modifier = Modifier.padding(horizontal = 8.dp))
                    IconButton(onClick = { viewModel.setCount(name, count + 1) }) {
                        Icon(Icons.Default.Add, contentDescription = "Увеличить")
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = newName,
            onValueChange = { newName = it },
            label = { Text("Название") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = newCount,
            onValueChange = { newCount = it.filter { ch -> ch.isDigit() } },
            label = { Text("Количество") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Button(onClick = {
            val count = newCount.toIntOrNull()
            if (newName.isNotBlank() && count != null) {
                viewModel.setCount(newName.trim(), count)
                newName = ""
                newCount = ""
            }
        }, modifier = Modifier.align(Alignment.End)) {
            Text("Добавить")
        }
    }
}