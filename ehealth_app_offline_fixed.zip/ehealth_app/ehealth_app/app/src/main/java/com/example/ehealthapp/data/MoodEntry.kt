package com.example.ehealthapp.data

/**
 * Data class representing a mood diary entry. Each entry records
 * the user's mood, craving level, stress and energy on a scale from 0–10
 * alongside a timestamp of when the entry was created. Storing the
 * timestamp allows us to sort entries chronologically when displaying
 * trends back to the user.
 */
data class MoodEntry(
    val mood: Int,
    val craving: Int,
    val stress: Int,
    val energy: Int,
    val timestamp: Long = System.currentTimeMillis()
)