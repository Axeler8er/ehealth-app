package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Mini psychodiagnostic screen with a short questionnaire. The user
 * responds to several statements on a 0–3 scale (disagree → agree) and
 * receives feedback about potential levels of concern based on the total
 * score. This is not a diagnostic tool but a general check‑in.
 */
@Composable
fun PsychodiagnosticScreen() {
    val questions = listOf(
        "Я часто чувствую усталость и апатию",
        "Мне сложно контролировать свои эмоции",
        "Я испытываю сильную тягу к веществам",
        "Мне сложно концентрироваться на задачах",
        "Я чувствую себя одиноким"
    )
    val responses = remember { mutableStateListOf(*IntArray(questions.size) { 0 }.toTypedArray()) }
    var result by remember { mutableStateOf<String?>(null) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Психодиагностика", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        questions.forEachIndexed { index, q ->
            Text(q, style = MaterialTheme.typography.bodyLarge)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                (0..3).forEach { option ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        RadioButton(
                            selected = responses[index] == option,
                            onClick = { responses[index] = option }
                        )
                        Text(option.toString())
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Button(onClick = {
            val sum = responses.sum()
            result = when {
                sum <= 5 -> "Минимальный уровень беспокойства"
                sum <= 10 -> "Низкий уровень беспокойства"
                sum <= 15 -> "Средний уровень беспокойства"
                else -> "Высокий уровень беспокойства — обратитесь к специалисту"
            }
        }, modifier = Modifier.align(Alignment.End)) {
            Text("Оценить")
        }
        result?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }
    }
}