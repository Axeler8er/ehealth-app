package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ehealthapp.R
import com.example.ehealthapp.data.MoodEntry
import com.example.ehealthapp.viewmodel.MoodViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Screen displaying a list of past mood entries. Entries are shown
 * newest first along with a formatted date/time and the ratings for
 * mood, craving, stress and energy. If there are no entries a
 * placeholder is displayed.
 */
@Composable
fun MoodTrendsScreen(viewModel: MoodViewModel = viewModel()) {
    val entries by viewModel.moodEntries.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Динамика настроения", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        if (entries.isEmpty()) {
            Image(
                painter = painterResource(id = R.drawable.mood_diary_mascot),
                contentDescription = null,
                modifier = Modifier.height(140.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("Нет записей", style = MaterialTheme.typography.bodyLarge)
        } else {
            LazyColumn {
                items(entries) { entry ->
                    MoodEntryRow(entry)
                }
            }
        }
    }
}

@Composable
private fun MoodEntryRow(entry: MoodEntry) {
    val dateFormat = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
    val dateString = dateFormat.format(Date(entry.timestamp))
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(dateString, style = MaterialTheme.typography.labelLarge)
        Text("Настроение: ${entry.mood}", style = MaterialTheme.typography.bodyMedium)
        Text("Тяга: ${entry.craving}", style = MaterialTheme.typography.bodyMedium)
        Text("Стресс: ${entry.stress}", style = MaterialTheme.typography.bodyMedium)
        Text("Энергия: ${entry.energy}", style = MaterialTheme.typography.bodyMedium)
    }
}