package com.example.ehealthapp.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Repository for managing the user's pill inventory. Each entry is stored as
 * a simple "name|count" string in a set preference. When loaded the entries
 * are transformed into a Map<String, Int>. Updating an entry will replace
 * any existing record for that name. This repository deliberately keeps
 * counts as integers and leaves validation (e.g. non‑negative) to callers.
 */
class PillInventoryRepository(private val context: Context) {
    private val Context.dataStore by preferencesDataStore(name = "inventory_prefs")
    private val INVENTORY = stringSetPreferencesKey("inventory_entries")

    /**
     * A flow emitting the inventory as a map of medication name to count.
     */
    val inventory: Flow<Map<String, Int>> = context.dataStore.data.map { prefs ->
        val entries = prefs[INVENTORY] ?: emptySet()
        entries.mapNotNull { parseEntry(it) }.toMap()
    }

    /**
     * Set the count for a given medication. If the medication name
     * already exists in the stored set its previous entry will be removed.
     */
    suspend fun setCount(name: String, count: Int) {
        context.dataStore.edit { prefs ->
            val entries = prefs[INVENTORY]?.toMutableSet() ?: mutableSetOf()
            // remove existing entry for this medication
            entries.removeIf { it.startsWith("$name|") }
            entries.add(formatEntry(name, count))
            prefs[INVENTORY] = entries
        }
    }

    private fun formatEntry(name: String, count: Int): String = "$name|$count"

    private fun parseEntry(str: String): Pair<String, Int>? {
        val parts = str.split("|")
        return if (parts.size == 2) {
            val name = parts[0]
            val count = parts[1].toIntOrNull() ?: return null
            name to count
        } else null
    }
}