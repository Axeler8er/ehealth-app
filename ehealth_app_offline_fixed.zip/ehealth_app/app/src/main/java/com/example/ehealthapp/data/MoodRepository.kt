package com.example.ehealthapp.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Repository managing persistence of mood diary entries using
 * DataStore. Entries are serialised to a simple comma‑delimited
 * string representation and stored in a string set under the key
 * [MOOD_ENTRIES]. When the flow is collected the entries are
 * deserialised and sorted in reverse chronological order.
 */
class MoodRepository(private val context: Context) {
    private val Context.dataStore by preferencesDataStore(name = "mood_prefs")
    private val MOOD_ENTRIES = stringSetPreferencesKey("mood_entries")

    /**
     * A flow of all mood entries sorted newest first. It re‑emits
     * whenever the underlying DataStore data changes.
     */
    val moodEntries: Flow<List<MoodEntry>> = context.dataStore.data.map { prefs ->
        prefs[MOOD_ENTRIES]?.mapNotNull { parseEntry(it) }
            ?.sortedByDescending { it.timestamp } ?: emptyList()
    }

    /**
     * Persist a new mood entry by appending it to the existing set
     * stored in DataStore. Each entry is uniquely identified by its
     * timestamp.
     */
    suspend fun addEntry(entry: MoodEntry) {
        context.dataStore.edit { prefs ->
            val current = prefs[MOOD_ENTRIES]?.toMutableSet() ?: mutableSetOf()
            current.add(formatEntry(entry))
            prefs[MOOD_ENTRIES] = current
        }
    }

    private fun formatEntry(entry: MoodEntry): String =
        "${entry.mood},${entry.craving},${entry.stress},${entry.energy},${entry.timestamp}"

    private fun parseEntry(str: String): MoodEntry? {
        val parts = str.split(",")
        return if (parts.size == 5) {
            try {
                val mood = parts[0].toInt()
                val craving = parts[1].toInt()
                val stress = parts[2].toInt()
                val energy = parts[3].toInt()
                val timestamp = parts[4].toLong()
                MoodEntry(mood, craving, stress, energy, timestamp)
            } catch (e: Exception) {
                null
            }
        } else null
    }
}