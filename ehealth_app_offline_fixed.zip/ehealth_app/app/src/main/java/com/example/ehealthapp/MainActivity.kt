package com.example.ehealthapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ehealthapp.ui.theme.EHealthAppTheme
import com.example.ehealthapp.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EHealthApp()
        }
    }
}

@Composable
fun EHealthApp() {
    EHealthAppTheme {
        val navController = rememberNavController()
        AppNavHost(navController)
    }
}

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen(onFinished = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Splash.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Home.route) {
            HomeScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Screen.MoodDiary.route) {
            MoodDiaryScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Screen.MoodTrends.route) {
            MoodTrendsScreen()
        }
        composable(Screen.PillReminder.route) {
            PillReminderScreen()
        }
        composable(Screen.Mindfulness.route) {
            MindfulnessScreen()
        }
        composable(Screen.Motivation.route) {
            MotivationScreen()
        }
        composable(Screen.CBTPractices.route) {
            CBTPracticesScreen()
        }
        composable(Screen.PillInventory.route) {
            PillInventoryScreen()
        }
        composable(Screen.Emergency.route) {
            EmergencyScreen()
        }
        composable(Screen.Psychodiagnostic.route) {
            PsychodiagnosticScreen()
        }
        composable(Screen.BusLocation.route) {
            BusLocationScreen()
        }
        composable(Screen.Education.route) {
            EducationScreen()
        }
        composable(Screen.ElizaChat.route) {
            ElizaScreen()
        }
        composable(Screen.Monitor.route) {
            MonitorScreen()
        }
    }
}