package com.example.ehealthapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ehealthapp.data.PillInventoryRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel managing the pill inventory. Exposes a state flow of
 * medication counts and provides a method to adjust counts for a given
 * medication. Persistence is handled by [PillInventoryRepository].
 */
class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PillInventoryRepository(application)

    val inventory: StateFlow<Map<String, Int>> = repository.inventory.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyMap()
    )

    fun setCount(name: String, count: Int) {
        viewModelScope.launch {
            repository.setCount(name, count)
        }
    }
}