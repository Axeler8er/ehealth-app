package com.example.ehealthapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ehealthapp.data.MoodEntry
import com.example.ehealthapp.data.MoodRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel wrapping [MoodRepository]. It exposes a state flow of all
 * diary entries and provides a suspend call to add a new entry. Using
 * [AndroidViewModel] gives access to the application context for
 * constructing the repository.
 */
class MoodViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MoodRepository(application)

    /** Flow of mood entries collected as state within the view model. */
    val moodEntries: StateFlow<List<MoodEntry>> = repository.moodEntries.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    /**
     * Add a new mood entry to the repository. Launches on the
     * viewModelScope to ensure the call is tied to the lifecycle.
     */
    fun addEntry(entry: MoodEntry) {
        viewModelScope.launch {
            repository.addEntry(entry)
        }
    }
}