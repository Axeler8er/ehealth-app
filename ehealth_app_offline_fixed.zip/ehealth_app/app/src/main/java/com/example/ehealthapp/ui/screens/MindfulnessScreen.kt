package com.example.ehealthapp.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.ehealthapp.R
import kotlinx.coroutines.delay

/**
 * Mindfulness screen guiding the user through a one‑minute breathing
 * exercise. A progress bar fills over 60 seconds and resets when the
 * exercise is complete or when the user starts a new session.
 */
@Composable
fun MindfulnessScreen() {
    var running by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(running) {
        if (running) {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 60_000, easing = LinearEasing)
            )
            // once finished, stop
            running = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Дыхательная практика", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(id = R.drawable.mindfulness_mascot),
            contentDescription = null,
            modifier = Modifier.height(150.dp)
        )
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(progress = progress.value, modifier = Modifier.fillMaxSize().height(8.dp))
        Spacer(Modifier.height(16.dp))
        Text(
            text = if (running) "Дышите..." else "Нажмите старт для 1‑минутной практики",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { running = true }, enabled = !running) {
            Text(if (running) "В процессе" else "Старт")
        }
    }
}