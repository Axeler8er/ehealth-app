package com.example.ehealthapp.ui.screens

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object MoodDiary : Screen("mood_diary")
    object MoodTrends : Screen("mood_trends")
    object PillReminder : Screen("pill_reminder")
    object Mindfulness : Screen("mindfulness")
    object Motivation : Screen("motivation")
    object CBTPractices : Screen("cbt_practices")
    object PillInventory : Screen("pill_inventory")
    object Emergency : Screen("emergency")
    object Psychodiagnostic : Screen("psychodiagnostic")
    object BusLocation : Screen("bus_location")
    object Education : Screen("education")
    object ElizaChat : Screen("eliza_chat")
    object Monitor : Screen("monitor")
}