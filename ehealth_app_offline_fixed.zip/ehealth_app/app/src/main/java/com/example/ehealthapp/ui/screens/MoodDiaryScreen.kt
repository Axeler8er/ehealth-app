package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.BarChart
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ehealthapp.R
import com.example.ehealthapp.data.MoodEntry
import com.example.ehealthapp.ui.screens.Screen
import com.example.ehealthapp.viewmodel.MoodViewModel

/**
 * Mood diary screen allowing the user to rate several emotional states via
 * sliders. The results are saved locally via [MoodViewModel] and the
 * trends screen can be navigated to via the top action button. An image
 * of the mascot is displayed to add warmth to the interface.
 */
@Composable
fun MoodDiaryScreen(
    onNavigate: (String) -> Unit,
    viewModel: MoodViewModel = viewModel()
) {
    // Local state for each rating. We default to midpoint values.
    var mood by remember { mutableStateOf(5f) }
    var craving by remember { mutableStateOf(5f) }
    var stress by remember { mutableStateOf(5f) }
    var energy by remember { mutableStateOf(5f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Дневник настроения", style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { onNavigate(Screen.MoodTrends.route) }) {
                Icon(Icons.Default.BarChart, contentDescription = "Посмотреть динамику")
            }
        }
        Spacer(Modifier.height(12.dp))
        // Mascot image at top
        Image(
            painter = painterResource(id = R.drawable.mood_diary_mascot),
            contentDescription = null,
            modifier = Modifier
                .height(120.dp)
                .fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        RatingQuestion(
            question = "Я чувствую себя...",
            value = mood,
            onValueChange = { mood = it }
        )
        RatingQuestion(
            question = "Уровень тяги...",
            value = craving,
            onValueChange = { craving = it }
        )
        RatingQuestion(
            question = "Уровень стресса...",
            value = stress,
            onValueChange = { stress = it }
        )
        RatingQuestion(
            question = "Уровень энергии...",
            value = energy,
            onValueChange = { energy = it }
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            // Save entry then navigate back or show confirmation
            viewModel.addEntry(
                MoodEntry(
                    mood = mood.toInt(),
                    craving = craving.toInt(),
                    stress = stress.toInt(),
                    energy = energy.toInt()
                )
            )
            onNavigate(Screen.MoodTrends.route)
        }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Сохранить")
        }
    }
}

@Composable
private fun RatingQuestion(
    question: String,
    value: Float,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(text = question, style = MaterialTheme.typography.bodyLarge)
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..10f
        )
    }
}