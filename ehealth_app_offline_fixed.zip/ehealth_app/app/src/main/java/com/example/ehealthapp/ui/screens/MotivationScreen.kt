package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.ehealthapp.R

/**
 * Motivation screen displaying random inspirational quotes to encourage
 * the user to remain on their recovery journey. The user can tap the
 * button to cycle through different quotes. A calming mascot image is
 * shown to reinforce positivity.
 */
@Composable
fun MotivationScreen() {
    val quotes = listOf(
        "Каждый день — это новая возможность.",
        "Вы сильнее, чем думаете.",
        "Маленькие шаги приводят к большим результатам.",
        "Доверяйте процессу и себе.",
        "Завтра будет лучше, если начать сегодня."
    )
    var current by remember { mutableStateOf(quotes.random()) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Мотивация", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(id = R.drawable.mindfulness_mascot),
            contentDescription = null,
            modifier = Modifier.height(140.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(current, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(horizontal = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = { current = quotes.random() }) {
            Text("Следующая цитата")
        }
    }
}