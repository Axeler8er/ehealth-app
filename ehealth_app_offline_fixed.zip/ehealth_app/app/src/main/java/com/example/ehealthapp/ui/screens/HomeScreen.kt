package com.example.ehealthapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ehealthapp.R

data class Feature(val label: String, val route: String, val icon: ImageVector)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    val features = listOf(
        Feature("Mood Diary", Screen.MoodDiary.route, Icons.Default.Mood),
        Feature("Pill Reminder", Screen.PillReminder.route, Icons.Default.Alarm),
        Feature("Mindfulness", Screen.Mindfulness.route, Icons.Default.SelfImprovement),
        Feature("Motivation", Screen.Motivation.route, Icons.Default.Favorite),
        Feature("CBT", Screen.CBTPractices.route, Icons.Default.School),
        Feature("Inventory", Screen.PillInventory.route, Icons.Default.Inventory),
        Feature("Emergency", Screen.Emergency.route, Icons.Default.Call),
        Feature("Diagnosis", Screen.Psychodiagnostic.route, Icons.Default.Assessment),
        Feature("Blue Bus", Screen.BusLocation.route, Icons.Default.DirectionsBus),
        Feature("Education", Screen.Education.route, Icons.Default.Book),
        Feature("Eliza Chat", Screen.ElizaChat.route, Icons.Default.Chat),
        Feature("Monitor", Screen.Monitor.route, Icons.Default.Visibility)
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.mood_diary_mascot),
                contentDescription = null,
                modifier = Modifier
                    .size(90.dp)
                    .padding(end = 16.dp)
            )
            Column {
                Text(
                    text = "Добро пожаловать!",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Выберите функцию", 
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f)) {
            items(features) { feature ->
                FeatureCard(feature) { onNavigate(feature.route) }
            }
        }
    }
}

@Composable
fun FeatureCard(feature: Feature, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .height(120.dp),
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                feature.icon,
                contentDescription = feature.label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = feature.label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 4.dp),
                maxLines = 2
            )
        }
    }
}

@Preview
@Composable
private fun HomeScreenPreview() {
    HomeScreen(onNavigate = {})
}