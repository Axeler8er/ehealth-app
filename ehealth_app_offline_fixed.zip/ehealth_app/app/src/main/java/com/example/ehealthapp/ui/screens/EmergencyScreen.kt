package com.example.ehealthapp.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.ehealthapp.R

/**
 * Emergency screen providing quick access to emergency services and
 * displaying a short plan of action in crisis situations. A call
 * button triggers the phone dialer with the emergency number.
 */
@Composable
fun EmergencyScreen() {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Экстренная помощь", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(id = R.drawable.emergency_mascot),
            contentDescription = null,
            modifier = Modifier.height(140.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Если вы или кто‑то рядом находится в опасности, звоните 112 немедленно. Держите при себе Налоксон и знайте, где его можно получить.",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
            context.startActivity(intent)
        }) {
            Text("Позвонить 112")
        }
    }
}